# Capstone-Project---Car-accident-severity-Week-1-_Introduction-Business-Problem
This repository consists of the section " Introduction / Business Problem" belonging to Week 1 of the Capstone Project - Car Accident Severity
